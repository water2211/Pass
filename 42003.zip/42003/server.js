const express = require("express");
const app = express();
const port = 42003;


// const lineNotify = require('line-notify-nodejs')('123');
const bodyParser = require('body-parser')
const { urlencoded } = require('body-parser')


app.use(bodyParser.urlencoded({ extended: true }))
app.use(express.static('public'))

app.use(express.urlencoded());
app.use("/", express.static(__dirname + "/view/"));
app.use("/buy", express.static(__dirname + "/view"));
app.use("/success", express.static(__dirname + "/view/success.html"));

app.post('/', (req, res) => {
});
app.post('/buy', (req, res) => {
    var name = req.body.name;
    var phone = req.body.phone;
    var lineid = req.body.lineid;


//    lineNotify.notify({
//        message: `ลูกค้าลงทะเบียนสั่ง samrt watch : \n ลูกค้าชื่อ : ${name} \n เบอร์โทร : ${phone} \n ไลน์ไอดี : ${lineid} \n`,
//    }).then(() => {
//        console.log('send completed!');
//    });

    console.log('name : ' + req.body.name ,'\nphone : ' + req.body.phone,'\nLineid : ' + req.body.lineid);
    res.redirect(`/success`);
});


app.listen(port, () => {
    console.log(`Server is running at ${port}`);
});